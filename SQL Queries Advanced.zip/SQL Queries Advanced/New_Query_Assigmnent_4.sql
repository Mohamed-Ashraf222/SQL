-- Active: 1720903011268@@127.0.0.1@3306@companydb
USE CompanyDB;

--subTask 1, 2
INSERT INTO Employee VALUES
('Mohamed', 'Ashraf', '102658', '2004-03-19', '56 Ain-Shams st. Cairo', 'M', 10000, '445566', 30),
('Ahmed', 'Salah', '102880', '2003-10-22', '12 Elhorya st. Cairo', 'M', DEFAULT, DEFAULT, 80)

SELECT * FROM companydb.Employee;

--subTask 3
INSERT INTO Department VALUES
('DEPT SW', 102, '112233', '2006-01-11')

SELECT * FROM department 
WHERE Dnum = 102

--subTask 4
UPDATE Department SET MGRSSN = '968574', MGRStartDate = '2024-07-16' WHERE
Dnum = 102;

UPDATE Department SET MGRSSN = '102658', MGRStartDate = '2024-07-16' WHERE
Dnum = 20;

UPDATE Employee SET Dno = 20 WHERE
SSN = '102658';

UPDATE Employee SET Dno = 20, SuperSSN = '102658' WHERE
SSN = '102880';

SELECT * FROM employee
WHERE SSN IN (968574 ,102880, 102658)

--subTask 5
SELECT * FROM Employee WHERE SSN = '223344';

DELETE
FROM Employee
WHERE SSN = '223344'

UPDATE Employee SET Dno = 10, Salary = 1800 WHERE
SSN = 102880;

UPDATE department SET MGRSSN = 102880, MGRStartDate = '2024-07-16' WHERE
Dnum = 10;

UPDATE dependent SET ESSN = 102880 WHERE
ESSN = 223344;

UPDATE employee SET superSSN = 102880 WHERE
superSSN = 223344;

UPDATE works_for SET ESSN = 102880 WHERE
ESSN = 223344;

--subTask 6
UPDATE employee SET salary = salary * 1.20 WHERE
SSN = 102658;

SELECT * FROM employee 
WHERE SSN = 102658;
--Select Queries 

-- 1
SELECT * FROM employee;

-- 2
SELECT Fname, Lname, Salary, Dno FROM employee;

-- 3
SELECT Pname, Plocation, Dnum FROM project;

-- 4
SELECT Fname, Salary, Salary * 12 AS ANNUAL_SALARY, Salary * 12 * 0.1 AS ANNUAL_COMM
FROM employee;

-- 5 
SELECT Fname, Lname, SSN
FROM employee 
WHERE Salary > 1000;

-- 6
SELECT Fname, Lname, SSN
FROM employee 
WHERE Salary * 12 > 10000;

-- 7
SELECT Fname, Lname, Salary 
FROM employee
WHERE Sex = 'F';

-- 8
SELECT Dname, Dnum
FROM department
WHERE MGRSSN = 968574;

-- 9 
SELECT Pnumber, Pname, Plocation
FROM project
WHERE Dnum = 10;

--Implement the queries

-- 1
SELECT Pnumber, Pname, Plocation 
FROM project
WHERE City = 'Cairo' OR City = 'Alex';

-- 2
SELECT * FROM employee
WHERE Dno = 30 AND Salary > 1000 AND Salary < 2000;

-- 3
SELECT CONCAT(Fname, ' ', Lname) AS fullName, Address
FROM employee 
WHERE Dno IN (SELECT Dnum FROM Project WHERE Pname = 'AL Solimaniah');

-- 4
SELECT CONCAT(Fname, ' ', Lname) AS fullName
FROM employee
WHERE SSN IN (SELECT ESSN FROM works_for WHERE Hours > 20);

-- 5
SELECT SSN, Fname, Lname, Pname 
FROM employee
JOIN project ON Dno = Dnum;

-- 6
SELECT CONCAT(Fname, ' ', Lname) AS fullName, Dnum, Dname
FROM department
JOIN employee ON MGRSSN = SSN;

-- 7
SELECT * FROM employee
LEFT JOIN department ON Dno = Dnum;

-- 8



-- 9 
SELECT CONCAT(Fname, ' ', Lname) AS fullName, SUBSTRING_INDEX(Address, '.', -1) AS City 
FROM employee
ORDER BY City;


-- 10
SELECT * FROM employee 
WHERE SSN IN (SELECT MGRSSN FROM department);

-- 11
SELECT *,
    CASE 
        WHEN Salary > 2000 THEN  'High Salary'
        WHEN salary > 1000 AND Salary < 2000 THEN 'Medium Salary'
        ELSE  'Low Salary'
    END AS salaryCategory
FROM employee;

-- 12
SELECT *,
    CASE 
        WHEN City = 'Cairo' THEN 'High Risk'
        WHEN City = 'Giza' THEN 'Medium Risk'
        WHEN City = 'Alex' THEN 'Low Risk'
    END AS riskLevel
FROM Project;

-- 13
SELECT *,
    CASE
        WHEN Salary > 2000 THEN Salary * 0.15
        ELSE Salary * 0.1
    END AS Bounses
FROM employee;

-- 14
SELECT *,
    CASE 
        WHEN superSSN IS NOT NULL THEN 'Active'
        ELSE 'Independent'
    END AS status
FROM employee;

-- 15
CREATE VIEW employeeInformation AS 
SELECT * FROM employee;

-- 16
CREATE PROCEDURE procedureInfo(IN employeeID CHAR(6))
BEGIN
    SELECT * FROM employee WHERE SSN = employeeID;
END;

CALL procedureInfo(102880);

-- 17
DELIMITER //
CREATE Function fnSalary(E_salary INT)
RETURNs VARCHAR(50)
DETERMINISTIC
BEGIN
    DECLARE salaryEvaluation VARCHAR(50);

    CASE 
        WHEN E_salary > 3000 THEN SET salaryEvaluation = 'Higher Salary';
        ELSE SET salaryEvaluation  = 'Normal';
    END CASE;

    RETURN salaryEvaluation;
END //

DELIMITER;

SELECT fnSalary(4000);

DELIMITER //
CREATE FUNCTION fnsalary2(E_salary INT)

RETURNS varchar(50)
DETERMINISTIC

BEGIN
    DECLARE salaryEvaluation VARCHAR(50);

    CASE 
        WHEN E_salary > 2000 THEN SET salaryEvaluation = 'Higher Salary';
        ELSE SET salaryEvaluation = 'Lower Salary';
    END CASE;

    RETURN salaryEvaluation;
END //

DELIMITER;

SELECT fnsalary2(1000)